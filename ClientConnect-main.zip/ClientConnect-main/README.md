<h1><strong>ClientConnect</strong></h1>
<h2>This project i tried to connect to my own api in https://test-deploy-api-by-giabao.herokuapp.com/users</h2>
<h2>Open console to see the result</h2>
<h2>Thanks for paying your attention</h2>
<a href="https://client-connect-eight.vercel.app/" target="_blank">Live demo</a>
